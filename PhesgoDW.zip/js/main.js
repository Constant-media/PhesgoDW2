var _tl,_tl2,
    _expandedFlag = false,
    _isiText = document.getElementById('isi-text'),
    _container = document.getElementById('isi'),
    _isiControls = document.getElementById('isi-controls'),
    _scrollerBeingDragged = false,
    _scroller,_scrollerline,_arrowUp,_arrowDown,
    _normalizedPosition,
    _topPosition,
    _contentPosition = 0,
    _percentY,
    autoScroll,//Interval
    autoScrollSpeed = 80,//
    scrollStep = 1,//Arrow click seek
    _textScrollHeight,
    _isiFullTime = 450,
    _isiFullHeight,
    _isiHeight;
;

window.onload = function() { Enabler.isInitialized() ? politeload() : Enabler.addEventListener( studio.events.StudioEvent.INIT, politeload ); }

function politeload() {
    console.log('preloads');
    Enabler.loadScript('https://s0.2mdn.net/ads/studio/cached_libs/gsap_3.9.1_min.js');
    Enabler.isPageLoaded() ? checkGreensockReady() : Enabler.addEventListener( studio.events.StudioEvent.PAGE_LOADED, checkGreensockReady );
}

function checkGreensockReady() { window.gsap ? politeInit() : setTimeout( checkGreensockReady, 50 ); }
function politeInit() { Enabler.isVisible() ? init() : Enabler.addEventListener(studio.events.StudioEvent.VISIBLE,init); }

function loadSTP(){
    ipSTP = document.createElement('script');
    ipSTP.setAttribute('type', 'text/javascript');
    ipSTP.setAttribute('src', 'https://s0.2mdn.net/ads/studio/cached_libs/scrolltoplugin_3.2.4_min.js');
    document.getElementsByTagName('head')[0].appendChild(ipSTP);

    ipSTP.addEventListener('load', init, false);
}

function init(){
    var css = document.createElement( 'link' );
    css.setAttribute( 'rel', 'stylesheet' );
    css.setAttribute( 'type', 'text/css' );
    css.setAttribute( 'href', "css/style.css" );
    document.getElementsByTagName('head')[0].appendChild(css);
    
    elem('#btnExpand').addEventListener('click', expandedByClick)
    elem('#btnIcon').addEventListener('click', expandedByClick)

    elem("#btnExit").addEventListener('click', clickTagHandler)
    elem("#btnFPI").addEventListener('click', clickTagHandler2)
    elem("#urlFDA").addEventListener('click', clickTagHandler3)
    elem("#logoGenentech").addEventListener('click', clickTagHandler4)
    elem("#btnGAP").addEventListener('click', clickTagHandler5)

  //***** Start - Scroll creation and events registering
  createScroll(false, true);

    _tl = gsap.timeline();
    css.addEventListener('load', loadSTP, false);
}

function loadSTP(){
    ipSTP = document.createElement('script');
    ipSTP.setAttribute('type', 'text/javascript');
    ipSTP.setAttribute('src', 'https://s0.2mdn.net/ads/studio/cached_libs/scrolltoplugin_3.2.4_min.js');
    document.getElementsByTagName('head')[0].appendChild(ipSTP);

    ipSTP.addEventListener('load', loadFonts, false);
}

function loadFonts(){
  var ipFont = document.createElement( 'link' );
  ipFont.setAttribute( 'rel', 'stylesheet' );
  ipFont.setAttribute( 'type', 'text/css' );
  ipFont.setAttribute( 'href', 'https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@100;300;400;500;600;700&display=swap' );
  document.getElementsByTagName('head')[0].appendChild(ipFont);

    ipFont.addEventListener('load', initAnimations, false);
}

function initAnimations(){
    var css = document.createElement( 'link' );
    css.setAttribute( 'rel', 'stylesheet' );
    css.setAttribute( 'type', 'text/css' );
    css.setAttribute( 'href', 'style.css' );
    document.getElementsByTagName('head')[0].appendChild(css);

  //***** Start - Scroll creation and events registering
    createScroll(false, true);

    _tl = gsap.timeline();
    _tl2 = gsap.timeline();

    css.addEventListener('load', initAnimations, false);

    document.addEventListener('touchstart', touchHandler, true);
    document.addEventListener('touchmove', touchHandler, true);
    document.addEventListener('touchend', touchHandler, true);
    document.addEventListener('touchcancel', touchHandler, true);
}


function initAnimations(){
  console.time('animationTotalTime');
  console.time('TotalTime');

  _isiFullHeight = _isiText.scrollHeight;

  _tl
  .to('.banner',{duration:.25,opacity:1})

  .addLabel('F1')
  .fromTo('#person_f1',{opacity:0, scale:1, webkitFilter:'blur(5px)', filter:'blur(5px)'},{duration:.5, opacity:1, scale:1, webkitFilter:'blur(0px)', filter:'blur(0px)', ease:'power2.out'},'<+=.1')
  .fromTo('.f1_copy',{opacity:0},{duration:.25, opacity:1, ease:'power2.out'},'<+=.25')
  .to('.f1',{duration:.5, opacity:0, ease:'power2.out',onStart:timeStamps, onStartParams:['F1']},'+=1.45')

  .addLabel('F2')
  .to('#bg_1',{duration:.25, y:-28, x:6, scale:1.2})
  .to('#person_f1',{duration:.7, scale:1.7, x:120, y:416, rotate:-5, webkitFilter:'blur(5px)' ,filter:'blur(5px)', ease:'power2.out'},'<')
  .to('#person_f1',{duration:1.1, opacity:0, ease:'power2.out'},'<')
  .fromTo('#person_f2',{opacity:0, webkitFilter:'blur(5px)', filter:'blur(5px)'},{duration:.25, opacity:1, webkitFilter:'blur(0px)', filter:'blur(0px)', ease:'power2.out'},'<+=.25')
  .fromTo('.f2_copy',{opacity:0},{duration:.25, opacity:1, ease:'power2.out'},'<+=.25')
  .to('.f2',{duration:.25, opacity:0, ease:'power2.out',onStart:timeStamps, onStartParams:['F2']},'+=.7')

  .addLabel('F3')
  .fromTo('#illustration_f3',{opacity:0, scale:.3},{duration:.25, opacity:1, scale:1, ease:"back.out(1.7)"})
  .fromTo('.f3_copy',{opacity:0, y:50},{duration:.2, opacity:1, y:0, ease:'power2.out'})
  .to('.f3',{duration:.35, opacity:0, ease:'power2.out',onStart:timeStamps, onStartParams:['F3']},'+=2.1')

  .addLabel('F4')
  .fromTo('#illustration_f4',{opacity:0, scale:.3},{duration:.25, opacity:1, scale:1, ease:"back.out(1.7)"})
  .fromTo('.f4_copy',{opacity:0, y:50},{duration:.2, opacity:1, y:0, ease:'power2.out'})
  .to('.f4',{duration:.35, opacity:0, ease:'power2.out',onStart:timeStamps, onStartParams:['F4']},'+=1.25')

  .addLabel('F5')
  .fromTo('#illustration_f5',{opacity:0, scale:.3},{duration:.25, opacity:1, scale:1, ease:"back.out(1.7)"})
  .fromTo('.f5_copy',{opacity:0, y:50},{duration:.2, opacity:1, y:0, ease:'power2.out'})
  .to('.f5',{duration:.35, opacity:0, ease:'power2.out',onStart:timeStamps, onStartParams:['F5']},'+=2.8')

  .addLabel('F6')
  .fromTo('#bg_2',{opacity:0},{duration:.25, opacity:.8, ease:'power2.out'})
  .to('#actor_portrayal',{duration:.25, opacity:1, ease:'power2.out'},'<')
  .fromTo('#person_f6',{opacity:0, scale:1, webkitFilter:'blur(5px)', filter:'blur(5px)'},{duration:.25, opacity:1, scale:1, webkitFilter:'blur(0px)', filter:'blur(0px)', ease:'power2.out'},'<')
  .fromTo('#copy6',{opacity:0, y:25},{duration:.2, opacity:1, y:0, ease:'power2.out'})
  .fromTo('.f7_copy',{opacity:0, y:50},{duration:.2, opacity:1, y:0, ease:'power2.out'},'<')
  .to(['#person_f6'],{duration:.25, opacity:0, ease:'power2.out',onStart:timeStamps, onStartParams:['F6']},'+=.5')

  .addLabel('F7')
  .to('#bg_2',{duration:.25, scale:1.05, ease:'power2.out'})
  .to('#person_f6',{duration:.7, scale:2, x:418, y:720, rotate:-5, webkitFilter:'blur(5px)' ,filter:'blur(5px)', ease:'power2.out'},'<')
  .to('#person_f6',{duration:1.2, opacity:0, ease:'power2.out'},'<')
  .fromTo('#person_f7',{opacity:0, webkitFilter:'blur(5px)', filter:'blur(5px)'},{duration:.5, opacity:1, webkitFilter:'blur(0px)', filter:'blur(0px)', ease:'power2.out', onComplete:timeStamps, onCompleteParams:['F7']},'<')

  .call(function(){console.timeEnd('animationTotalTime','<= End Frame')})
  .call(function(){console.timeEnd('TotalTime'); toggleExpanded(); },null,'+=2.5')

  ;
}

function timeStamps (frame){
  console.timeLog('animationTotalTime','<= ' + frame);
}

function expandedByClick () {
  _expandedFlag = true;
  toggleExpanded();
}

function toggleExpanded () {
  var isiHeight = gsap.getProperty('#isi', 'height');

  if (isiHeight < 700 && !gsap.isTweening('#isi')) {
    gsap.to('#isi',{duration: .8, height: 1660, top:100});
    gsap.to('#header_ISI',{duration: .8,top:0});
    gsap.to('.scroller',{duration: .8, height: 516});
    gsap.set(elem('#header_ISI #btnIcon'),{scaleY: -1});
    _isiText.scrollTop= 0; // Reset ISI scroll to init position
    elem('#btnExpand').innerHTML = 'Collapse';
    _tl.pause();

    TweenMax.delayedCall(1, function() {
      var isiHeight = gsap.getProperty('#isi', 'height');
      if (isiHeight != 1660 && !gsap.isTweening('#isi')) {
        gsap.to('#isi',{duration: .8, height: 1660, top:100});
        gsap.to('#header_ISI',{duration: .8,top:0});
        gsap.to('.scroller',{duration: .8, height: 516});
        _isiText.scrollTop= 0; // Reset ISI scroll to init position
        gsap.set(elem('#header_ISI #btnIcon'),{scaleY: -1});
        elem('#btnExpand').innerHTML = 'Collapse';
        _tl.pause();
      }
    });

  } else if (isiHeight == 1660 && !gsap.isTweening('#isi')) {
    gsap.to('#isi',{duration: .8, height: 516, top:1245});
    gsap.to('#header_ISI',{duration: .8,top:1129});
    gsap.to('.scroller',{duration: .8, height: 74});
    _isiText.scrollTop= 0; // Reset ISI scroll to init position
    gsap.set(['#header_ISI #btnIcon'],{scaleY: 1});

    if (_tl.totalDuration >= 15 ) {
        console.log('EF')
    }else{
        _tl.play();
    }

    _isiText.scrollTop = 0; // Reset ISI scroll to init position
    elem('#btnExpand').innerHTML = 'Expand';
  }
}

//***** Scrolling functions *****//
function createScroll(hasArrows,hasScroller){//***** Scrolling function - Creation(init)
    hasArrows = typeof hasArrows !== 'undefined' ? hasArrows: true;
    hasScroller = typeof hasScroller !== 'undefined' ? hasScroller: true;
    if (hasArrows){
        _arrowUp= document.createElement('div');
        _arrowUp.id = 'arrowUp';
        _arrowUp.className = 'retina';
        _isiControls.appendChild(_arrowUp);
    }

    if (hasScroller){
        _scrollerline= document.createElement('div');
        _scrollerline.className = hasArrows? 'isiLineWithArrows': 'isiLineNoArrows';
        _isiControls.appendChild(_scrollerline);

        _scroller = document.createElement('div');
        _scroller.className = 'scroller';
        _scrollerline.appendChild(_scroller);
    }

    if (hasArrows){
        _arrowDown= document.createElement('div');
        _arrowDown.id = 'arrowDown';
        _arrowDown.className = 'retina';
        _isiControls.appendChild(_arrowDown);
    }

//Listeners
    if (hasScroller){
        _isiText.addEventListener('scroll',moveScroller);
        _scroller.addEventListener('mousedown',startDrag);
        _scrollerline.addEventListener('click',seekTo);
        window.addEventListener('mousemove',scrollBarScroll);

    }

    if (hasArrows){
        _arrowUp.addEventListener('mousedown',scrollUp);
        _arrowDown.addEventListener('mousedown',scrollDown);
        _arrowUp.addEventListener('mouseup',scrollStop);
        _arrowDown.addEventListener('mouseup',scrollStop);
    }
    _isiText.addEventListener('wheel',scrollStop);
    window.addEventListener('mouseup',stopDrag);
}

function touchHandler(event) {
  console.log('hola');
    var touch = event.changedTouches[0];

    var simulatedEvent = document.createEvent('MouseEvent');
        simulatedEvent.initMouseEvent({
        touchstart: 'mousedown',
        touchmove: 'mousemove',
        touchend: 'mouseup'
    }[event.type], true, true, window, 1,
        touch.screenX, touch.screenY,
        touch.clientX, touch.clientY, false,
        false, false, false, 0, null);

    touch.target.dispatchEvent(simulatedEvent);
    // event.preventDefault();
}

function seekTo(evt){//***** Scrolling function - Seeks to an specific point
    var normalPosition = (evt.clientY - _isiControls.offsetParent.offsetTop - _scrollerline.offsetTop) / _scrollerline.clientHeight;
    _textScrollHeight = _isiText.scrollHeight - _container.offsetHeight;//gets the text height(offset) to scroll
    _isiText.scrollTop = normalPosition * _textScrollHeight;
    scrollStop();
}

function startDrag(evt) {//***** Scrolling function - Starts dragging when holds scroller button
    _scrollerline.removeEventListener('click',seekTo);
    _normalizedPosition = evt.clientY - _scrollerline.scrollTop;
    _contentPosition = _isiText.scrollTop;
    _scrollerBeingDragged = true;
    scrollStop();
}

function stopDrag(evt) {//***** Scrolling function - Stops dragging when releases scroller button
    if (typeof buttonPress != 'undefined' && buttonPress)
    scrollStop(buttonPress);
    _scrollerBeingDragged = false;
}

function scrollBarScroll(evt) {//***** Scrolling function - Moves text up/down
        evt.preventDefault();
    if (_scrollerBeingDragged === true) {
        var mouseDifferential = evt.clientY - _normalizedPosition;
        var scrollEquivalent = mouseDifferential * (_isiText.scrollHeight / _scrollerline.clientHeight);
        _isiText.scrollTop = _contentPosition + scrollEquivalent;
    }
}

function moveScroller(evt) {//***** Scrolling function - Moves scroller button up/down
    evt.preventDefault();
    _textScrollHeight = _isiText.scrollHeight - _container.offsetHeight;//gets the text height(offset) to scroll
    var remainOffsetHieght = _textScrollHeight - _isiText.scrollTop;//when scrolling,it gets the remaining height(top offset)
    var percentHeigh = 1 - remainOffsetHieght/_textScrollHeight;//transform to a percentage
    _scroller.style.top = Math.abs((_scrollerline.offsetHeight -_scroller.offsetHeight) * percentHeigh) + 'px';//To equivalent scroller line height

    // var isiHeight = gsap.getProperty('#isi', 'height');
    // if (isiHeight == 1660 && !gsap.isTweening('#isi') && !_expandedFlag) {
    //   _expandedFlag = true;
    // }
}

function scrollUp(){//***** Scrolling function - Sets text a step up
    console.log('up');
    scrollStop();
    buttonPress = setInterval(function(){_isiText.scrollTop-=scrollStep},100);
}

function scrollDown(){//***** Scrolling function - Sets text a step down
    console.log('down')
    scrollStop();
    buttonPress = setInterval(function(){_isiText.scrollTop+=scrollStep},100);
}

function scrollStop(){//***** Scrolling function - Clears buttons interval
    _tl.killTweensOf(_isiText);
}

function elem(id){return document.querySelector(id)};

function clickTagHandler() {
    Enabler.exit('btnExit');
}

function clickTagHandler2() {
    Enabler.exit('btnFPI');
}

function clickTagHandler3() {
    Enabler.exit('urlFDA');
}

function clickTagHandler4() {
    Enabler.exit('logoGenentech');
}

function clickTagHandler5() {
    Enabler.exit('urlPhesgo');
}